class AppImages {
  static final logo = "assets/images/logo.png";
  static final feirinha = "assets/images/feirinha.jpg";
  static final feirinha2 = "assets/images/feirinha2.jpg";
  static final about = "assets/images/sobre.jpg";
}
