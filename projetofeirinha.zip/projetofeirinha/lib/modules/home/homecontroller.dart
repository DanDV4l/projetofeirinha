class HomeController {
  int currentPage = 0;

  void setPage(int index) {
    currentPage = index;
  }
}
